<!-- START NAVBAR SECTION -->
<!-- START NAVBAR SECTION -->
<header  id="header" class="nav-header">
<link rel="stylesheet" type="text/css" href="Design/css/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="Design/fonts/css/all.min.css">
		<link rel="stylesheet" type="text/css" href="Design/css/main-style.css">
		<link rel="stylesheet" type="text/css" href="Design/css/responsive.css">

		<!-- GOOGLE FONTS -->

		<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=PT+Sans+Narrow&display=swap" rel="stylesheet">
    
    
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class = "container">
            <p class="navbar-brand" href="#">
            <img src="design/images/logo.jpg" alt="Logo" style="width: 50px; height: 50px; margin-right: 15px;">
                <span style = "color:white">varni CarRental</span>
</p>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#yahyaNavbar" aria-controls="yahyaNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="yahyaNavbar">
                <ul class="navbar-nav" style = "margin-left: auto!important;">
                    <li class="nav-item active">
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./#brands">Brands</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="res.php">Reserve</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>