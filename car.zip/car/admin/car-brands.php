<?php
session_start();

// Page Title
$pageTitle = 'Car Brands';

// Includes
include 'connect.php';
include 'Includes/functions/functions.php'; 
include 'Includes/templates/header.php';

// Check if user is already logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {
?>

    <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Car Brands</h1>
            
        </div>

        <?php
        // Add new brand
        if (isset($_POST['add_brand_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $brand_name = test_input($_POST['brand_name']);
            $brand_image = rand(0,100000) . '_' . $_FILES['brand_image']['name'];
            move_uploaded_file($_FILES['brand_image']['tmp_name'], "Uploads/images/" . $brand_image);

            $stmt = $con->prepare("INSERT INTO car_brands (brand_name, brand_image) VALUES (?, ?)");
            $stmt->bind_param("ss", $brand_name, $brand_image);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>New Car Brand has been inserted successfully</div>";
            } else {
                echo "<div class='alert alert-danger'>Error occurred: " . $con->error . "</div>";
            }

            $stmt->close();
        }

        // Delete brand
        if (isset($_POST['delete_brand_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $brand_id = $_POST['brand_id'];

            $stmt = $con->prepare("DELETE FROM car_brands WHERE brand_id = ?");
            $stmt->bind_param("i", $brand_id);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Car Brand has been deleted successfully</div>";
            } else {
                echo "<div class='alert alert-danger'>Error occurred: " . $con->error . "</div>";
            }

            $stmt->close();
        }

        // Edit brand
        if (isset($_POST['edit_brand_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $brand_id = $_POST['brand_id'];
            $brand_name = test_input($_POST['brand_name']);
            $brand_image = $_FILES['brand_image']['name'] ? rand(0, 100000) . '_' . $_FILES['brand_image']['name'] : null;

            if ($brand_image) {
                move_uploaded_file($_FILES['brand_image']['tmp_name'], "Uploads/images/" . $brand_image);
                $stmt = $con->prepare("UPDATE car_brands SET brand_name = ?, brand_image = ? WHERE brand_id = ?");
                $stmt->bind_param("ssi", $brand_name, $brand_image, $brand_id);
            } else {
                $stmt = $con->prepare("UPDATE car_brands SET brand_name = ? WHERE brand_id = ?");
                $stmt->bind_param("si", $brand_name, $brand_id);
            }

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Car Brand has been updated successfully</div>";
            } else {
                echo "<div class='alert alert-danger'>Error occurred: " . $con->error . "</div>";
            }

            $stmt->close();
        }
        ?>

        <!-- Display Car Brands Table -->
        <?php
        $stmt = $con->prepare("SELECT * FROM car_brands");
        $stmt->execute();
        $result = $stmt->get_result();
        ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Car Brands</h6>
            </div>
            <div class="card-body">
                <button class="btn btn-success btn-sm" style="margin-bottom: 10px;" type="button" data-toggle="modal" data-target="#add_new_brand" data-placement="top">
                    <i class="fa fa-plus"></i> Add New Brand
                </button>

                <div class="modal fade" id="add_new_brand" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Brand</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="car-brands.php" method="POST" enctype="multipart/form-data">
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="brand_name">Brand name</label>
                                        <input type="text" id="brand_name_input" class="form-control" placeholder="Brand Name" name="brand_name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="brand_image">Brand image</label>
                                        <input type="file" id="brand_image_input" class="form-control" name="brand_image" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-info" name="add_brand_sbmt">Add Brand</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Brand ID</th>
                                <th>Brand Name</th>
                                <th>Brand Image</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($brand = $result->fetch_assoc()) {
                                echo "<tr>";
                                    echo "<td>{$brand['brand_id']}</td>";
                                    echo "<td>{$brand['brand_name']}</td>";
                                    echo "<td style='width:30%'>";
                                        echo "<img src='Uploads/images/{$brand['brand_image']}' alt='{$brand['brand_name']}' class='img-fluid img-thumbnail'>";
                                    echo "</td>";
                                    echo "<td>";
                                        $delete_data = "delete_{$brand['brand_id']}";
                                        $edit_data = "edit_{$brand['brand_id']}";
                                        ?>
                                        <div class="btn-group" role="group" aria-label="Manage Brands">
                                            <button class="btn btn-warning btn-sm rounded-0" type="button" data-toggle="modal" data-target="#<?php echo $edit_data; ?>" data-placement="top">
                                                <i class="fa fa-edit"></i> 
                                            </button>
                                            <button class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="modal" data-target="#<?php echo $delete_data; ?>" data-placement="top">
                                                <i class="fa fa-trash"></i> 
                                            </button>
                                        </div>
                                        <div class="modal fade" id="<?php echo $edit_data; ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo $edit_data; ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <form action="car-brands.php" method="POST" enctype="multipart/form-data">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Edit Brand</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="brand_id" value="<?php echo $brand['brand_id']; ?>">
                                                            <div class="form-group">
                                                                <label for="brand_name">Brand name</label>
                                                                <input type="text" id="brand_name_input" class="form-control" placeholder="Brand Name" name="brand_name" value="<?php echo $brand['brand_name']; ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="brand_image">Brand image</label>
                                                                <input type="file" id="brand_image_input" class="form-control" name="brand_image">
                                                                <small>Current image:</small><br>
                                                                <img src='Uploads/images/<?php echo $brand['brand_image']; ?>' alt='<?php echo $brand['brand_name']; ?>' class='img-fluid img-thumbnail' style='max-width: 100%; max-height: 150px;'>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="edit_brand_sbmt" class="btn btn-info">Update Brand</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="<?php echo $delete_data; ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo $delete_data; ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <form action="car-brands.php" method="POST">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Delete Brand</h5>
                                                            <input type="hidden" value="<?php echo $brand['brand_id']; ?>" name="brand_id">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Are you sure you want to delete this Brand "<?php echo $brand['brand_name']; ?>"?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="delete_brand_sbmt" class="btn btn-danger">Delete</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <?php
                                    echo "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
<?php 
include 'Includes/templates/footer.php'; 
} else {
    header('Location: login.php');
    exit();
}
?>
