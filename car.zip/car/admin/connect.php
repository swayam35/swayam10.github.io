<?php
$host = 'localhost';
$dbname = 'car_rental';
$user = 'root';
$pass = '';

// Create connection
$con = new mysqli($host, $user, $pass, $dbname);

// Set character set to UTF-8
$con->set_charset('utf8');

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} else {
    // Uncomment this line to confirm a successful connection
    // echo 'Connected successfully';
}

// Alternative connection handling (similar to your second try-catch block)
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
} else {
    // Uncomment this line to confirm a successful connection
    // echo 'Connected successfully';
}
?>
