<?php
session_start();

// Page Title
$pageTitle = 'Contact Messages';

// Includes
include 'connect.php';
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';

// Check if the user is logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {
?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Contact Messages</h1>
            
        </div>

        <!-- Contact Messages Table -->
        <?php
        // Fetch contact messages from the database
        $stmt = $con->prepare("SELECT * FROM contacts ORDER BY created_at DESC");
        $stmt->execute();
        $result = $stmt->get_result(); // Use get_result() to retrieve a result set
        $rows_contacts = $result->fetch_all(MYSQLI_ASSOC); // Fetch all rows as associative array
        ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Contact Messages</h6>
            </div>
            <div class="card-body">
                <!-- Contact Messages Table -->
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Subject</th>
                                <th scope="col">Message</th>
                                <th scope="col">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Display each contact message
                            foreach ($rows_contacts as $contact) {
                                echo "<tr>";
                                    echo "<td>" . htmlspecialchars($contact['id']) . "</td>";
                                    echo "<td>" . htmlspecialchars($contact['name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($contact['email']) . "</td>";
                                    echo "<td>" . htmlspecialchars($contact['subject']) . "</td>";
                                    echo "<td>" . htmlspecialchars($contact['message']) . "</td>";
                                    echo "<td>" . htmlspecialchars($contact['created_at']) . "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php 
    // Include Footer
    include 'Includes/templates/footer.php';
} else {
    // Redirect to login if not logged in
    header('Location: index.php');
    exit();
}
?>
