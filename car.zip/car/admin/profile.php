<?php
session_start();

// Page Title
$pageTitle = 'View Profile';

// Includes
include 'connect.php'; // Ensure this uses MySQLi
include 'Includes/templates/header.php';

// Check if the connection is established
if (!isset($conn)) {
    die("Database connection failed.");
}

// Check if the user is logged in
if (isset($_SESSION['username_yahya_car_rental'])) {
    $username = $_SESSION['username_yahya_car_rental'];

    // Initialize variables with default values
    $email = 'Not available';
    $phone = 'Not available';
    $profile_picture = 'Uploads/default-profile.png';  // Default profile picture path

    // Fetch profile data from the database
    try {
        // Prepare the SQL statement
        $stmt = $conn->prepare("SELECT * FROM profile WHERE username = ?");
        $stmt->bind_param("s", $username); // Bind the parameter
        $stmt->execute(); // Execute the statement
        $result = $stmt->get_result(); // Get the result set

        if ($result->num_rows > 0) {
            // Fetch the profile data
            $profile = $result->fetch_assoc();

            // Populate the profile details if found
            $email = $profile['email'];
            $phone = $profile['phone'];

            // If profile picture is available, use it; otherwise, fall back to default
            if (!empty($profile['profile_picture'])) {
                // Assuming 'profile_picture' only contains the filename, prepend the folder
                $profile_picture = 'Uploads/' . $profile['profile_picture'];
            }
        } else {
            $_SESSION['error_message'] = "Profile not found.";
        }
    } catch (Exception $e) {
        error_log("Error fetching profile: " . $e->getMessage());
        $_SESSION['error_message'] = "Error fetching profile.";
    }
?>

<section class="profile-section" id="profile-view">
    <div class="container">
        <h1 class="h3 mb-4 text-gray-800">Profile</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-6 sm-padding">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">User Information</h6>
                    </div>
                    <div class="card-body">
                        <p><strong>Username:</strong> <?= htmlspecialchars($username); ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($email); ?></p>
                        <p><strong>Phone:</strong> <?= htmlspecialchars($phone); ?></p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 sm-padding">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Profile Picture</h6>
                    </div>
                    <div class="card-body">
                        <div class="profile-picture" style="background-image: url('<?= htmlspecialchars($profile_picture); ?>');">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<?php 
    include 'Includes/templates/footer.php'; 
} else {
    header('Location: login.php');
    exit();
}
?>

<style>
    .profile-picture {
        width: 70%; /* Adjust width as necessary */
        height: 300px; /* Set a height for the profile picture */
        background-size: cover; /* Ensure the background image covers the area */
        background-position: center; /* Center the image */
        border-radius: 10px; /* Optional: round the corners */
        border: 1px solid #ddd; /* Optional: add a border */
    }
</style>
