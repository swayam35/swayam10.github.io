<?php
ob_start();
session_start();

// Page Title
$pageTitle = 'Update Profile Setting';

// Includes
include 'connect.php'; // Ensure this uses MySQLi
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';

// Check if the connection is established
if (!isset($conn)) {
    die("Database connection failed.");
}

// Function to update user profile information (including profile picture)
function updateUserProfile($conn) {
    $username = test_input($_POST['username']);
    $email = test_input($_POST['email']);
    $phone = test_input($_POST['phone']);
    $profile_image = $_FILES['profile_picture']['name'] ? rand(0, 100000) . '_' . $_FILES['profile_picture']['name'] : null;

    // Check if a new profile picture is uploaded
    if ($profile_image) {
        // Move the uploaded image to the target directory
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], "uploads/" . $profile_image);
        
        // Prepare SQL to update both profile details and the image
        $stmt = $conn->prepare("UPDATE profile SET email = ?, phone = ?, profile_picture = ? WHERE username = ?");
        $stmt->bind_param("ssss", $email, $phone, $profile_image, $username);
    } else {
        // Update only the profile details if no image is provided
        $stmt = $conn->prepare("UPDATE profile SET email = ?, phone = ? WHERE username = ?");
        $stmt->bind_param("sss", $email, $phone, $username);
    }

    if ($stmt->execute()) {
        // Set success message in the session
        $_SESSION['success_message'] = "Profile updated successfully";
        $_SESSION['email'] = $email;
        $_SESSION['phone'] = $phone;
        $stmt->close();
        return true;
    } else {
        error_log("Error updating profile: " . $stmt->error);
        $_SESSION['error_message'] = "Error updating profile.";
        return false;
    }
}

// Check if the user is logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {

    // Handle profile update
    if (isset($_POST['update_profile']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        updateUserProfile($conn);
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Prepare for form
    $username = $_SESSION['username_yahya_car_rental'] ?? '';
    $email = $_SESSION['email'] ?? '';
    $phone = $_SESSION['phone'] ?? '';
?>

<section class="profile-section" id="profile-settings">
    <div class="container">
        <h1 class="h3 mb-4 text-gray-800">Update Profile Settings</h1>
        
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-6 sm-padding">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">User Information</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($username); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($phone); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="profile_picture">Profile Picture</label>
                                <input type="file" class="form-control-file" name="profile_picture" accept="image/*">
                            </div>
                            <button type="submit" class="btn btn-primary" name="update_profile">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    include 'Includes/templates/footer.php'; 
} else {
    header('Location: login.php');
    exit();
}

ob_end_flush();
?>
